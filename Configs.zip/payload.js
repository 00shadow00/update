
[
	    {
	  "Name":"SELECT PAYLOAD",
	  "Info":"Do not torrent",
	  "Payload": "869e9c9c8a86a840b6d0dee6e8bee0dee4e8ba80ecd2c4cae45cc6deda4090a8a8a05e625c62b6c6e4d8ccbab6c6e4d8ccbaa09ea6a840d0e8e8e0e6745e5eecd2c4cae45cc6deda5e40b6e0e4dee8dec6ded8bab6c6e4d8ccba90dee6e87440ecd2c4cae45cc6dedab6c6e4d8ccbab05a9edcd8d2dcca5a90dee6e87440ecd2c4cae45cc6dedab6c6e4d8ccba86dedcdccac6e8d2dedc744096cacae05a82d8d2eccab6c6e4d8ccba869e9c9c8a86a840b6d0dee6e8bee0dee4e8ba40b6e0e4dee8dec6ded8bab6c6e4d8ccbab6c6e4d8ccba"
	  },
  {
	  "Name":"GTM-GS-GOWATCH-or-GS-PROMO",
	  "Info":"Send GS10-GS50 to 8080",
	  "Payload":{
		  "Proxy":{
			  "Custom":false,
			  "Remote":"",
			  "Port":""
		  },
		  "Url":"e6eae0e0dee4e85cf2deeae8eac4ca5cc6deda5ce6ce",
		  "Host":true,
		  "Online-Host":true,
		  "Forward-Host":true,
		  "Reverse-Proxy":false,
		  "Keep-Alive":true
	  }
  },
  {
	  "Name":"GTM-GS-GOWATCH-or-GS-PROMO2",
	  "Info":"Send GS10-GS50 to 8080",
	   "Payload":{
		  "Proxy":{
			  "Custom":false,
			  "Remote":"",
			  "Port":""
		  },
		  "Url":"869e9c9c8a86a840b6d0dee6e8bee0dee4e8ba40b6e0e4dee8dec6ded8bab6c6e4d8ccba90dee6e87440e6e6d85ccee6e8c2e8d2c65cc6deda80dccae8ced8dec4ca5cc6deda5ce6ce806464645c62646e5c626a5c6c625e6664b6c6e4d8ccbab05a9edcd8d2dcca5a90dee6e87440c8c2ec685ae6e0cacae6e8cae6e85cced8dec4ca5cc6deda5ce0d080ccc2e6e8c6d8deeac85cceca80dccaeee6c4f2e8ca5ce0d0806464645c62646e5c626a5c6c625e6664b6c6e4d8ccbab05a8cdee4eec2e4c85a90dee6e87440ced8dec4c2d85a685ad8ece65adec8e4c25a6e5cdee0cae4c25adad2dcd25c40dccae880eee05cdaca80e6dae6c6c2e6e8cae45cc6deda806464645c62646e5c626a5c6c625e6664b6c6e4d8ccba86dedcdccac6e8d2dedc744096cacae05a82d8d2eccab6c6e4d8ccbaaae6cae45a82cecadce87440b6eac2bab6c6e4d8ccbab6c6e4d8ccba14ced8dec4ca40cedeeec2e8c6d0",
		  "Host":true,
		  "Online-Host":true,
		  "Forward-Host":true,
		  "Reverse-Proxy":false,
		  "Keep-Alive":true
	  }
  },
  {
	  "Name":"SMART-ALLOUT-PROMO",
	  "Info":"Register to Any ALLOUT Promos send to 9999",
	   "Payload":{
		  "Proxy":{
			  "Custom":false,
			  "Remote":"",
			  "Port":""
		  },
		  "Url":"eeeeee5ccededeced8caecd2c8cade5cc6deda5ce6ce",
		  "Host":true,
		  "Online-Host":true,
		  "Forward-Host":true,
		  "Reverse-Proxy":false,
		  "Keep-Alive":true
	  }
  },
  {
	  "Name":"TNT-ML--PROMO",
	  "Info":"ML10 send to 4545",
	   "Payload":{
		  "Proxy":{
			  "Custom":false,
			  "Remote":"",
			  "Port":""
		  },
		  "Url":"d0d6ce606ee664705ad2dc5acc62685c62ca6260605cdccae8",
		  "Host":true,
		  "Online-Host":true,
		  "Forward-Host":true,
		  "Reverse-Proxy":false,
		  "Keep-Alive":true
	  }
  },
    {
	  "Name":"TNT-FB-PROMO",
	  "Info":"FB10 send to 4545",
	   "Payload":{
		  "Proxy":{
			  "Custom":false,
			  "Remote":"",
			  "Port":""
		  },
		  "Url":"d0d6ce606ee664705ad2dc5acc62685c62ca6260605cdccae8",
		  "Host":true,
		  "Online-Host":true,
		  "Forward-Host":true,
		  "Reverse-Proxy":false,
		  "Keep-Alive":true
	  }
  },
  {
	  "Name":"SUN-TU-PROMO",
	  "Info":"Send TU50-TU300 to 247",
	   "Payload":{
		  "Proxy":{
			  "Custom":false,
			  "Remote":"",
			  "Port":""
		  },
		  "Url":"869e9c9c8a86a840b6d0dee6e8bee0dee4e8ba80ecd2c4cae45cc6deda4090a8a8a05e625c62b6c6e4d8ccbab6c6e4d8ccbaa09ea6a840d0e8e8e0e6745e5eecd2c4cae45cc6deda5e40b6e0e4dee8dec6ded8bab6c6e4d8ccba90dee6e87440ecd2c4cae45cc6dedab6c6e4d8ccbab05a9edcd8d2dcca5a90dee6e87440ecd2c4cae45cc6dedab6c6e4d8ccba86dedcdccac6e8d2dedc744096cacae05a82d8d2eccab6c6e4d8ccba869e9c9c8a86a840b6d0dee6e8bee0dee4e8ba40b6e0e4dee8dec6ded8bab6c6e4d8ccbab6c6e4d8ccba",
		  "Host":true,
		  "Online-Host":false,
		  "Forward-Host":false,
		  "Reverse-Proxy":false,
		  "Keep-Alive":false
	  }
  },
  {
	  "Name":"SUN-TU-PROMO 2",
	  "Info":"Send TU50-TU300 to 247",
	   "Payload":{
		  "Proxy":{
			  "Custom":false,
			  "Remote":"",
			  "Port":""
		  },
		  "Url":"869e9c9c8a86a840b6d0dee6e8bee0dee4e8ba4090a8a8a05e625c62b6c6e4d8ccbab6c6e4d8ccbaa09ea6a840d0e8e8e0e6745e5eca726862665cce5cc2d6c2dac2d2cac8ceca5cdccae85e40b6e0e4dee8dec6ded8bab6c6e4d8ccba90dee6e87440ca726862665cce5cc2d6c2dac2d2cac8ceca5cdccae8b6c6e4d8ccbab6c6e4d8ccba",
		  "Host":true,
		  "Online-Host":false,
		  "Forward-Host":false,
		  "Reverse-Proxy":false,
		  "Keep-Alive":false
	  }
  },
  {
	  "Name":"SUN-TU-PROMO 3",
	  "Info":"Send TU50-TU300 to 247",
	   "Payload":{
		  "Proxy":{
			  "Custom":false,
			  "Remote":"",
			  "Port":""
		  },
		  "Url":"869e9c9c8a86a840b6d0dee6e8bee0dee4e8ba80ecd2c4cae45cc6deda4090a8a8a05e625c62b6c6e4d8ccbab6c6e4d8ccbaa0aaa840d0e8e8e0e6745e5eecd2c4cae45cc6deda5e40b6e0e4dee8dec6ded8bab6c6e4d8ccba90dee6e87440ecd2c4cae45cc6dedab6c6e4d8ccbab05a9edcd8d2dcca5a90dee6e87440ecd2c4cae45cc6dedab6c6e4d8ccbab05a8cdee4eec2e4c85a90dee6e87440ecd2c4cae45cc6dedab6c6e4d8ccba86dedcdccac6e8d2dedc744096cacae05a82d8d2eccab6c6e4d8ccbab6c6e4d8ccba",
		  "Host":true,
		  "Online-Host":false,
		  "Forward-Host":false,
		  "Reverse-Proxy":false,
		  "Keep-Alive":false
	  }
  }
]

