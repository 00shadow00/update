
[
	    {
	  "Name":"SELECT PAYLOAD",
	  "Info":"Do not torrent",
	  "Payload": "869e9c9c8a86a840b6d0dee6e8bee0dee4e8ba80ecd2c4cae45cc6deda4090a8a8a05e625c62b6c6e4d8ccbab6c6e4d8ccbaa09ea6a840d0e8e8e0e6745e5eecd2c4cae45cc6deda5e40b6e0e4dee8dec6ded8bab6c6e4d8ccba90dee6e87440ecd2c4cae45cc6dedab6c6e4d8ccbab05a9edcd8d2dcca5a90dee6e87440ecd2c4cae45cc6dedab6c6e4d8ccba86dedcdccac6e8d2dedc744096cacae05a82d8d2eccab6c6e4d8ccba869e9c9c8a86a840b6d0dee6e8bee0dee4e8ba40b6e0e4dee8dec6ded8bab6c6e4d8ccbab6c6e4d8ccba"
	  },
  {
	  "Name":"GTM-GS-GOWATCH-or-GS-PROMO",
	  "Info":"Send GS10-GS50 to 8080",
	  "Payload":{
		  "Proxy":{
			  "Custom":false,
			  "Remote":"",
			  "Port":""
		  },
		  "Url":"e6eae0e0dee4e85cf2deeae8eac4ca5cc6deda5ce6ce",
		  "Host":true,
		  "Online-Host":true,
		  "Forward-Host":true,
		  "Reverse-Proxy":false,
		  "Keep-Alive":true
	  }
  },
  
  {
	  "Name":"SMART-ALLOUT-PROMO",
	  "Info":"Register to Any ALLOUT Promos send to 9999",
	   "Payload":{
		  "Proxy":{
			  "Custom":false,
			  "Remote":"",
			  "Port":""
		  },
		  "Url":"eeeeee5ccededeced8caecd2c8cade5cc6deda5ce6ce",
		  "Host":true,
		  "Online-Host":true,
		  "Forward-Host":true,
		  "Reverse-Proxy":false,
		  "Keep-Alive":true
	  }
  },
  {
	  "Name":"TNT-ML--PROMO",
	  "Info":"ML10 send to 4545",
	   "Payload":{
		  "Proxy":{
			  "Custom":false,
			  "Remote":"",
			  "Port":""
		  },
		  "Url":"d0d6ce606ee664705ad2dc5acc62685c62ca6260605cdccae8",
		  "Host":true,
		  "Online-Host":true,
		  "Forward-Host":true,
		  "Reverse-Proxy":false,
		  "Keep-Alive":true
	  }
  },
    {
	  "Name":"TNT-FB-PROMO",
	  "Info":"FB10 send to 4545",
	   "Payload":{
		  "Proxy":{
			  "Custom":false,
			  "Remote":"",
			  "Port":""
		  },
		  "Url":"d0d6ce606ee664705ad2dc5acc62685c62ca6260605cdccae8",
		  "Host":true,
		  "Online-Host":true,
		  "Forward-Host":true,
		  "Reverse-Proxy":false,
		  "Keep-Alive":true
	  }
  },
  {
	  "Name":"SUN-TU50-PROMO",
	  "Info":"Find Sun FOR TU only config",
	   "Payload":{
		  "Proxy":{
			  "Custom":false,
			  "Remote":"",
			  "Port":""
		  },
		  "Url":"869e9c9c8a86a840b6d0dee6e8bee0dee4e8ba80ecd2c4cae45cc6deda4090a8a8a05e625c62b6c6e4d8ccbab6c6e4d8ccbaa09ea6a840d0e8e8e0e6745e5eecd2c4cae45cc6deda5e40b6e0e4dee8dec6ded8bab6c6e4d8ccba90dee6e87440ecd2c4cae45cc6dedab6c6e4d8ccbab05a9edcd8d2dcca5a90dee6e87440ecd2c4cae45cc6dedab6c6e4d8ccba86dedcdccac6e8d2dedc744096cacae05a82d8d2eccab6c6e4d8ccba869e9c9c8a86a840b6d0dee6e8bee0dee4e8ba40b6e0e4dee8dec6ded8bab6c6e4d8ccbab6c6e4d8ccba",
		  "Host":true,
		  "Online-Host":false,
		  "Forward-Host":false,
		  "Reverse-Proxy":false,
		  "Keep-Alive":false
	  }
  }
]